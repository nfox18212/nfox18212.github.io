# CSE 379 Lab 7 - Atari Video Cube
## Nathan Fox and Sebastien Bowen

This is the code base for the Atari Video cube file.  Please use all of the files provided in this tar archive.  The next section is usage instructions for using the custom debugging code for general faults.

# CSE 379 Custom Fault Debug Program

There are three files